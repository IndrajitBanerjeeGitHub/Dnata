﻿using System.Collections.Generic;

namespace TravelRepublic.FlightCodingTest.Models
{
    public class Flight
    {
        public IList<Segment> Segments { get; set; }
    }
}
