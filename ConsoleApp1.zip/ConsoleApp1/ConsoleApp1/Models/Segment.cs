﻿using System;

namespace TravelRepublic.FlightCodingTest.Models
{
    public class Segment
    {
        public DateTime DepartureDate { get; set; }
        public DateTime ArrivalDate { get; set; }
    }
}
