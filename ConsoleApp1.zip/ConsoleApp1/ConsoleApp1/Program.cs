﻿using System;

namespace TravelRepublic.FlightCodingTest
{
    public class Program
    {
        static void Main(string[] args)
        {
            FlightBuilder fltBuilder = new FlightBuilder();
            BeforeArrivalDate(fltBuilder);
            MoreThan2Hours(fltBuilder);
        }

        private static void BeforeArrivalDate(FlightBuilder fltBuilder)
        {
            var data = fltBuilder.GetFlights();
            for (int i = 0; i < data.Count; i++)
            {
                int len = data[i].Segments.Count;
                for (int j = 0; j < len; j++)
                {
                    DateTime dt = DateTime.Now;
                    var departure = data[i].Segments[j].DepartureDate;
                    var arrived = data[i].Segments[j].ArrivalDate;
                    int result = DateTime.Compare(departure, dt);
                    int newresult = DateTime.Compare(arrived,departure);
                    if (result < 0)
                    {
                        Console.WriteLine(" Depart before the current date/time: " + "Arrived Date: " + data[i].Segments[j].ArrivalDate + ",Departure Date " + data[i].Segments[j].DepartureDate + "<br/>");
                    }
                    if (newresult < 0)
                    {
                        Console.WriteLine(" Arrival date before the departure date: " + "Arrived Date: " + data[i].Segments[j].ArrivalDate + ",Departure Date " + data[i].Segments[j].DepartureDate + "<br/>");
                    }
                }
            }
        }
        private static void MoreThan2Hours(FlightBuilder flightBuilderb)
        {
            var data = flightBuilderb.GetFlights();
            for (int i = 0; i < data.Count; i++)
            {
                int len = data[i].Segments.Count;
                if (len == 2)
                {
                    for (int j = 0; j < len; j++)
                    {
                        var firstarrived = data[i].Segments[0].ArrivalDate;
                        var seconddeparture = data[i].Segments[1].DepartureDate;
                        var time = (seconddeparture - firstarrived).TotalHours;
                        if (time >= 2)
                        {
                            Console.WriteLine("Total gap of over two hours: FirstArrived Date" + firstarrived + "Seconddeparture Date" + seconddeparture + "<br/>");
                        }
                    }
                }
            }
        }
    }
}
